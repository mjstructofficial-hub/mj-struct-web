@echo off
setlocal
title Transcriptor de audio - MJ Struct
pushd "%~dp0" || goto error

if not exist "tools\uv.exe" goto incomplete
if not exist "tools\node.exe" goto incomplete
if not defined LOCALAPPDATA goto error

set "MJ_DATA=%LOCALAPPDATA%\MJ Struct\Transcriptor"
set "UV_PROJECT_ENVIRONMENT=%MJ_DATA%\env"
set "UV_PYTHON_INSTALL_DIR=%MJ_DATA%\python"
set "UV_CACHE_DIR=%MJ_DATA%\cache"
set "HF_HOME=%MJ_DATA%\modelo"
set "HF_HUB_DISABLE_IMPLICIT_TOKEN=1"
set "HF_HUB_DISABLE_TELEMETRY=1"

if not exist "%UV_PROJECT_ENVIRONMENT%\Scripts\python.exe" (
    echo Preparando el transcriptor por primera vez. Se necesita internet.
)

"%~dp0tools\uv.exe" --no-config run --project "%~dp0." --locked --managed-python --no-dev --no-build --python 3.14 python "%~dp0launcher.py" %*
set "MJ_EXIT=%ERRORLEVEL%"
popd
if "%MJ_EXIT%"=="0" exit /b 0
echo.
echo No se pudo completar el inicio. Revisa el mensaje anterior y la conexion.
if /I not "%~1"=="--no-browser" pause
exit /b %MJ_EXIT%

:incomplete
echo Extrae todos los archivos del ZIP en una carpeta antes de ejecutar Iniciar.bat.
popd
goto pause_error

:error
echo No se pudo abrir la carpeta del transcriptor o la carpeta de datos del usuario.
:pause_error
if /I not "%~1"=="--no-browser" pause
exit /b 1
