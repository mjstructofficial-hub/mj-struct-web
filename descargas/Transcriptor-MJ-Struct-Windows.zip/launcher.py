"""Inicia la aplicación en el navegador, únicamente en esta computadora."""

from __future__ import annotations

import argparse
import logging
import socket
import threading
import webbrowser
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, PlainTextResponse
from pydantic import ValidationError
from starlette.concurrency import run_in_threadpool

from engine import TranscribeRequest, transcribe_video


BASE_DIR = Path(__file__).resolve().parent
NODE_PATH = BASE_DIR / "tools" / "node.exe"
MAX_REQUEST_BYTES = 16_384


def create_app(port: int) -> FastAPI:
    local_host = f"127.0.0.1:{port}"
    local_origin = f"http://{local_host}"
    busy = threading.Lock()
    app = FastAPI(title="Transcriptor de MJ Struct", docs_url=None, redoc_url=None, openapi_url=None)

    @app.middleware("http")
    async def protect_local_app(request: Request, call_next):
        if request.headers.get("host") != local_host:
            return PlainTextResponse("Dirección local inválida.", status_code=400)
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Content-Security-Policy"] = (
            "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; "
            "connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
        )
        return response

    @app.get("/", include_in_schema=False)
    def home() -> FileResponse:
        return FileResponse(BASE_DIR / "index.html")

    @app.get("/assets/Mjstruct.webp", include_in_schema=False)
    def logo() -> FileResponse:
        return FileResponse(BASE_DIR / "assets" / "Mjstruct.webp", media_type="image/webp")

    def run_transcription(url: str) -> dict[str, str]:
        if not busy.acquire(blocking=False):
            raise HTTPException(409, "Hay una transcripción en curso. Espera a que termine.")
        try:
            return {"transcript": transcribe_video(url, node_path=NODE_PATH)}
        except HTTPException:
            raise
        except Exception as error:
            logging.getLogger(__name__).exception("Error al transcribir en el motor local")
            raise HTTPException(
                500, "No se pudo completar la transcripción. Revisa el mensaje de la consola.",
            ) from error
        finally:
            busy.release()

    @app.post("/transcribe")
    async def transcribe(request: Request) -> dict[str, str]:
        if request.headers.get("origin") != local_origin:
            raise HTTPException(403, "Abre el Transcriptor desde la dirección que indica el lanzador.")
        content_type = request.headers.get("content-type", "").partition(";")[0].strip().lower()
        if content_type != "application/json":
            raise HTTPException(415, "La solicitud debe enviarse como JSON.")

        body = bytearray()
        async for chunk in request.stream():
            if len(body) + len(chunk) > MAX_REQUEST_BYTES:
                raise HTTPException(413, "La solicitud supera el tamaño permitido.")
            body.extend(chunk)
        try:
            payload = TranscribeRequest.model_validate_json(body)
        except ValidationError as error:
            raise HTTPException(422, "Pega un enlace válido de hasta 2048 caracteres.") from error
        return await run_in_threadpool(run_transcription, payload.url)

    return app


def main() -> None:
    parser = argparse.ArgumentParser(description="Inicia el Transcriptor local de MJ Struct")
    parser.add_argument("--no-browser", action="store_true", help="Muestra la URL sin abrir el navegador")
    args = parser.parse_args()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
        url = f"http://127.0.0.1:{port}/"
        config = uvicorn.Config(
            create_app(port), host="127.0.0.1", port=port, proxy_headers=False,
            server_header=False, access_log=False,
        )
        server = uvicorn.Server(config)
        stopped = threading.Event()

        def show_address() -> None:
            while not server.started:
                if stopped.wait(0.05):
                    return
            print(f"Transcriptor de MJ Struct: {url}", flush=True)
            print("Deja esta ventana abierta. Pulsa Ctrl+C para cerrar el Transcriptor.", flush=True)
            if not args.no_browser:
                webbrowser.open(url, new=2)

        threading.Thread(target=show_address, daemon=True).start()
        try:
            server.run(sockets=[listener])
        finally:
            stopped.set()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
